# NOTICES 
Copyright © 2017, Impinj, Inc. All rights reserved.

Impinj gives no representation or warranty, express or implied, for accuracy or reliability of information in this document. Impinj reserves the right to change its products and services and this information at any time without notice.  

EXCEPT AS PROVIDED IN IMPINJ’S TERMS AND CONDITIONS OF SALE (OR AS OTHERWISE AGREED IN A VALID WRITTEN INDIVIDUAL AGREEMENTWITH IMPINJ), IMPINJ ASSUMES NO LIABILITY  WHATSOEVER AND IMPINJ DISCLAIMS ANY EXPRESS OR IMPLIEDWARRANTY, RELATED TO SALE AND/OR USE OF IMPINJ PRODUCTS INCLUDING LIABILITY OR WARRANTIES RELATING TO FITNESS FOR A PARTICULAR PURPOSE,MERCHANTABILITY,OR INFRINGEMENT.  

NO LICENSE, EXPRESS OR IMPLIED, BY ESTOPPEL OR OTHERWISE, TO ANY PATENT, COPYRIGHT, MASKWORK RIGHT, OR OTHER INTELLECTUALPROPERTY RIGHT IS GRANTED BY THIS DOCUMENT.  

Impinj assumes no liability for applications assistance or customer product design. Customers should provide adequate design and operating safeguards to minimize risks.  

Impinj products are not designed, warranted or authorized for use in any product or application where a malfunction may reasonably be expected to cause personal injury or death or property or environmental damage (“hazardous uses”) or for use in automotive environments. Customers must indemnify Impinj against any damages arising out of the use of Impinj products in any hazardous or automotive uses.  

Impinj, Monza, Speedway, xArray are trademarks or registered trademarks of Impinj, Inc. All other product or service names are trademarks of their respective companies. For a complete list of Impinj Trademarks visit: [www.impinj.com/trademarks](http://www.impinj.com/trademarks)
The products referenced in this document may be covered by one or more U.S. patents. See [www.impinj.com/patents](http://www.impinj.com/patents) for details. 
